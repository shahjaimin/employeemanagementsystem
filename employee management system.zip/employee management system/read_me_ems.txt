As a product owner i want to create a employee management system.

Resoluton:- I have created a small spring boot project/application to achive our requirement where, 

We can add employee.
we can get & delete employee based on employee Id.
We can get allocation of whole system as well as department & employee Also.
We can get all the employee details together.
we can delete the employee based on normal rules.
We can also get manager deatils to whom no one is reporting.

Rules (have added basic manager->employee(developer/tester) hierarchy rules) :- 

We need to add manager first of all, So other developer or tester can report to them.
Manager also can report to other manager.
If manager not reporting to other manager, In this case we consider that manager as a root/parent manager.
We can delete any developer,tester anytime without any restriction.
If we want to delete a manager then that manager should be reporting to other manager.
If we can delete mid level manager in this case whole hierarchy will be transferred.
Root/parent manager can't be deleted directly,First we need to delete other employee who are reporting to them.
Anytime we can delete all the employee in the system together.

for example:- 
we are creating 4 cases. M = manager, D=developer, T=tester, Digit stands for employee ID

 M1->M2->M3
 M4->M5->(T6,D7)
 M8->(T9,D10)
 M11->null

In this case f we consider manager's allocation is : 600, tester's allocation is: 1000 & developer's allocation is 2000
So department's total allocation = 10200
name    allocation
m1	1800
m4	4200
m8	3600
m11	0600
----
total	10200

same all other individual employee also have their allocation.

We can not delete the manager with Id: 1,4,8.
We can delete other employee anytime even manager with Id: 2,5.
If we delete manager with Id 2 then manager with Id 3 will report to manager with Id 1.
Same if we delete manager with Id 5 then tester with Id 6 and developer with Id 7 will report to manager with Id 4.

Application will be running on localhost:8080

request body for adding employee:-

{  
        "name": "jaimin shah",
        "designation": "manager",
        "reportingManagerId": 0,
        "department": "IT"
}

Method: POST
http://localhost:8080/ems/employee/add
//it is used to add employee

Method: GET
http://localhost:8080/ems/employee/byid/{id}
//it is used to get employee by employee id

Method: DELETE
http://localhost:8080/ems/employee/byid/{id}
//it is used to delete employee by employee id

Method: GET
http://localhost:8080/ems/employee/all
//it is used to get all employee

Method: DELETE
http://localhost:8080/ems/employee/all
//it is used to delete all employee

Method: GET
http://localhost:8080/ems/employee/count
//it is used to get total employee count in the application

Method: GET
http://localhost:8080/ems/employee/withoutemployee/{department}
//it is used to get manager deatils to whom no one is reporting

Method: GET
http://localhost:8080/ems/department/{department}
//it is used to get total employee count in the department

Method: GET
http://localhost:8080/ems/allocation/all
//it is used to get total allocation of all the employee in the application

Method: GET
http://localhost:8080/ems/allocation/bydepartment/{department}
//it is used to get total allocation of the department

Method: GET
http://localhost:8080//ems/allocation/byemployee/{id}
//it is used to get total allocation of all the employee