package com.ems.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.stereotype.Repository;

import com.ems.idao.IEmployeeDao;
import com.ems.model.Employee;
import com.ems.model.ResponseCodeAndMessage;
import com.ems.model.ResponseObject;

@Repository
public class EmployeeDao implements IEmployeeDao{

	//this map contains department name as key & map of employee Id with EmployeeEntity as value
	private static Map<String,Map<Long,Employee>> mapOfDepartmentNameWithEmployeeEntity = new HashMap<>();
	
	//this map contains employee ID as key & department name as value
	private static Map<Long,String> mapOfEmployeeIdWithDepartment = new HashMap<>();
	
	//this map contains department name as key & total allocation of department as value
	private static Map<String,Long> mapOfDepartmentNameWithAllocation = new HashMap<>();
	
	@Override
	public ResponseObject addEmployee(Employee employeeVo) {
		ResponseObject responseObjectVo=new ResponseObject();
		// creating EmployeeEntity
		Employee employeeEntity = new Employee();
		employeeEntity.setName(employeeVo.getName());
		employeeEntity.setDepartment(employeeVo.getDepartment());
		employeeEntity.setDesignation(employeeVo.getDesignation().trim().toUpperCase());
		employeeEntity.setReportingManagerId(employeeVo.getReportingManagerId());
		employeeEntity.setSalary(calculateSalary(employeeVo.getDesignation()));
		employeeEntity.setEmployeeId(calculateEmployeeId());
		employeeEntity.setTotalAllocation(employeeEntity.getSalary());

		if(!responseObjectVo.isError()) {
			if(mapOfDepartmentNameWithEmployeeEntity.containsKey(employeeEntity.getDepartment()))
			{	
				//department found, so validating reporting manager
				if(employeeVo.getReportingManagerId()!=0)
					responseObjectVo = validateReportingManager(employeeEntity);
				if(!responseObjectVo.isError())
				{
					if(employeeVo.getReportingManagerId()!=0)
						responseObjectVo = addReportingManagerAllocation(employeeEntity);
					
					//adding employee
					Map<Long,Employee> employeeMap= mapOfDepartmentNameWithEmployeeEntity.get(employeeEntity.getDepartment());
					employeeMap.put(employeeEntity.getEmployeeId(), employeeEntity);
					mapOfDepartmentNameWithEmployeeEntity.put(employeeEntity.getDepartment(), employeeMap);
					mapOfEmployeeIdWithDepartment.put(employeeEntity.getEmployeeId(), employeeEntity.getDepartment());
				}
			}
			else
			{
				//adding first employee, should be root/parent manager only
				if(employeeVo.getReportingManagerId()!=0)
				{
					responseObjectVo.setResponseCode(ResponseCodeAndMessage.ERROR_CODE);
					responseObjectVo.setResponseMessage(ResponseCodeAndMessage.MANAGER_NOTFOUND_WITH_ID+employeeVo.getReportingManagerId());
					return responseObjectVo;
				}
				
				//adding employee
				Map<Long,Employee> employeeMap= new HashMap<>();
				employeeMap.put(employeeEntity.getEmployeeId(), employeeEntity);
				mapOfDepartmentNameWithEmployeeEntity.put(employeeEntity.getDepartment(), employeeMap);
				mapOfEmployeeIdWithDepartment.put(employeeEntity.getEmployeeId(), employeeEntity.getDepartment());
			}
		}
		if(!responseObjectVo.isError())
		{
			// updating department allocation
			responseObjectVo = addDepartmentAllocation(employeeEntity.getDepartment(),employeeEntity.getSalary());
		}
		
		if(!responseObjectVo.isError())
		{
			responseObjectVo.setResponseObject(employeeEntity);
			responseObjectVo.setResponseMessage(ResponseCodeAndMessage.EMPLOYEE_CREATED_SUCCESSFULLY+employeeEntity.getEmployeeId());	
		}
		return responseObjectVo;
		
	}
	
	private Long calculateEmployeeId() {
		return mapOfEmployeeIdWithDepartment.size()==0?1l:mapOfEmployeeIdWithDepartment.entrySet().stream().max((entry1, entry2) -> entry1.getKey() > entry2.getKey() ? 1 : -1).get().getKey()+1;
	}

	private ResponseObject validateReportingManager(Employee employee) {
		ResponseObject responseObjectVo=new ResponseObject();
		Map<Long,Employee> employeeMap= mapOfDepartmentNameWithEmployeeEntity.get(employee.getDepartment());
		Employee manager = employeeMap.get(employee.getReportingManagerId());
		
		if(manager==null)
		{
			///manager id not found
			responseObjectVo.setResponseCode(ResponseCodeAndMessage.ERROR_CODE);
			responseObjectVo.setResponseMessage(ResponseCodeAndMessage.MANAGER_NOTFOUND_WITH_ID+employee.getReportingManagerId());
			return responseObjectVo;
		}
		
		if(!manager.getDesignation().equalsIgnoreCase("MANAGER")){
			//manager id found, but he/she is not manager
			responseObjectVo.setResponseCode(ResponseCodeAndMessage.ERROR_CODE);
			responseObjectVo.setResponseMessage("Reporting manager employee ID is incorrect. Employee ID with : "+employee.getReportingManagerId()+" is : "+manager.getDesignation());
		
		}
		return responseObjectVo;
	}

	private ResponseObject addDepartmentAllocation(String department, Long salary) {
		ResponseObject responseObjectVo=new ResponseObject();
		if(mapOfDepartmentNameWithAllocation.containsKey(department))
		{
			//department found
			Long allocation= mapOfDepartmentNameWithAllocation.get(department);
			allocation = allocation+salary;
			mapOfDepartmentNameWithAllocation.put(department, allocation);
		}
		else
		{
			//department not found
			mapOfDepartmentNameWithAllocation.put(department, salary);
		}
		return responseObjectVo;
	}
	
	private void removeDepartmentAllocation(String department, Long salary) {
			Long allocation= mapOfDepartmentNameWithAllocation.get(department);
			allocation = allocation-salary;
			mapOfDepartmentNameWithAllocation.put(department, allocation);
	}

	private ResponseObject addReportingManagerAllocation(Employee employee) {
		ResponseObject responseObjectVo=new ResponseObject();
		boolean isContainReportingManager = true;
		Long reportingManagerId = employee.getReportingManagerId();
		Map<Long,Employee> employeeMap= mapOfDepartmentNameWithEmployeeEntity.get(employee.getDepartment());
		if(employeeMap.get(reportingManagerId)==null)
		{
			responseObjectVo.setResponseCode(ResponseCodeAndMessage.ERROR_CODE);
			responseObjectVo.setResponseMessage(ResponseCodeAndMessage.MANAGER_NOTFOUND_WITH_ID+reportingManagerId);
			return responseObjectVo;
		}
		while(isContainReportingManager)
		{
			Employee manager = employeeMap.get(reportingManagerId);
			manager.setTotalAllocation(manager.getTotalAllocation()+employee.getSalary());
			employeeMap.put(reportingManagerId, manager);
			reportingManagerId=manager.getReportingManagerId();
			
			if(reportingManagerId==0) {
				isContainReportingManager = false;
			}
		}
		return responseObjectVo;
	}

	private Long calculateSalary(String designation) {
		Long salary=0l;
		designation = designation.trim().toUpperCase();
		switch(designation) {
		case ResponseCodeAndMessage.MANAGER: salary=ResponseCodeAndMessage.MANAGER_ALLOCATION; break;
		case ResponseCodeAndMessage.DEVELOPER: salary=ResponseCodeAndMessage.DEVELOPER_ALLOCATION; break;
		case ResponseCodeAndMessage.TESTER: salary=ResponseCodeAndMessage.TESTER_ALLOCATION; break;
		default : salary=0l; break;
		}
		return salary;
	}

	@Override
	public ResponseObject getTotalEmployee() {
		ResponseObject responseObjectVo=new ResponseObject();
		if(mapOfEmployeeIdWithDepartment.size()>0) {
			responseObjectVo.setResponseObject(mapOfDepartmentNameWithEmployeeEntity);
		}
		else {
			responseObjectVo.setResponseCode(ResponseCodeAndMessage.ERROR_CODE);
			responseObjectVo.setResponseMessage(ResponseCodeAndMessage.NO_EMPLOYEE_FOUND);
		}
		return responseObjectVo;
	}

	@Override
	public ResponseObject getEmployeeById(Long id) {
		ResponseObject responseObjectVo=new ResponseObject();
		
		//checking existing employee count
		if(mapOfEmployeeIdWithDepartment.size()>0) {
			//checking exiting employee ID
			if(mapOfEmployeeIdWithDepartment.get(id)==null) {
				responseObjectVo.setResponseCode(ResponseCodeAndMessage.ERROR_CODE);
				responseObjectVo.setResponseMessage(ResponseCodeAndMessage.NO_EMPLOYEE_FOUND_WITH+id);
			} else {
				Employee employee = mapOfDepartmentNameWithEmployeeEntity.get(mapOfEmployeeIdWithDepartment.get(id)).get(id);
				responseObjectVo.setResponseObject(employee);					
			}
			
		} else {
			responseObjectVo.setResponseCode(ResponseCodeAndMessage.ERROR_CODE);
			responseObjectVo.setResponseMessage(ResponseCodeAndMessage.NO_EMPLOYEE_FOUND);
		}
		return responseObjectVo;
	}

	@Override
	public ResponseObject deleteEmployeeById(Long id) {
		ResponseObject responseObjectVo=new ResponseObject();
		//checking existing employee count
		if(mapOfEmployeeIdWithDepartment.size()>0) {
			//checking exiting employee ID
			if(mapOfEmployeeIdWithDepartment.get(id)==null) {
				responseObjectVo.setResponseCode(ResponseCodeAndMessage.ERROR_CODE);
				responseObjectVo.setResponseMessage(ResponseCodeAndMessage.NO_EMPLOYEE_FOUND_WITH+id);
			} else {
				//proceed to delete employee
				responseObjectVo = deleteEmployee(id);
			}
		} else {
			responseObjectVo.setResponseCode(ResponseCodeAndMessage.ERROR_CODE);
			responseObjectVo.setResponseMessage(ResponseCodeAndMessage.NO_EMPLOYEE_FOUND);
		}
		return responseObjectVo;
	
	}

	private ResponseObject deleteEmployee(Long id) {
		ResponseObject responseObjectVo=new ResponseObject();
		Map<Long,Employee> mapOfEmployeeIdWithEmployeeEntity = mapOfDepartmentNameWithEmployeeEntity.get(mapOfEmployeeIdWithDepartment.get(id));
		Employee employee = mapOfEmployeeIdWithEmployeeEntity.get(id);
		
		if(employee==null)
		{
			//no employee found
			responseObjectVo.setResponseCode(ResponseCodeAndMessage.ERROR_CODE);
			responseObjectVo.setResponseMessage(ResponseCodeAndMessage.NO_EMPLOYEE_FOUND_WITH+id);
			return responseObjectVo;
		}
		
		Long reportingManagerId = employee.getReportingManagerId();
		boolean reportingFlag = false;
		List<Long> reportingEmployeeList = new ArrayList<>();
		//checking for employees who are reporting to this employee which id going to be deleted
		for (Entry<Long, Employee> iterable_element : mapOfEmployeeIdWithEmployeeEntity.entrySet()) {
			if(iterable_element.getValue().getReportingManagerId()==employee.getEmployeeId())
			{
				reportingEmployeeList.add(iterable_element.getKey());
			}
		}
		if(reportingEmployeeList.size()>0)
		{
			//true indicates some employees are reporting to employee which id going to be deleted
			reportingFlag = true;
		}
		if(reportingFlag)
		{
			if(reportingManagerId==0)
			{
				//if reporting manager of employee which id going to be deleted is root/parent manager, so we could not delete that employee
				responseObjectVo.setResponseCode(ResponseCodeAndMessage.ERROR_CODE);
				responseObjectVo.setResponseMessage(ResponseCodeAndMessage.REPORTING_MANAGER_NOTFOUND);
				return responseObjectVo;
			} else 
			{
				//we are updating child level employee's reporting manager id is to reporting manager id of reporting manager.
				for (Long iterable_element : reportingEmployeeList) {
					mapOfEmployeeIdWithEmployeeEntity.get(iterable_element).setReportingManagerId(reportingManagerId);
				}
			}
		} 
		
		boolean isContainReportingManager = true;
		while(isContainReportingManager)
		{
			Employee managerOfManager = mapOfEmployeeIdWithEmployeeEntity.get(reportingManagerId);
			if(managerOfManager!=null)
			{
				mapOfEmployeeIdWithEmployeeEntity.get(reportingManagerId).setTotalAllocation(managerOfManager.getTotalAllocation()-employee.getSalary());
				reportingManagerId=managerOfManager.getReportingManagerId();
					
				if(reportingManagerId==0)
					isContainReportingManager = false;
			}
			else {
				isContainReportingManager = false;
			}
				
		}
			// updating department allocation
			removeDepartmentAllocation(employee.getDepartment(),employee.getSalary());
				
			mapOfEmployeeIdWithEmployeeEntity.remove(id);
			mapOfDepartmentNameWithEmployeeEntity.put(employee.getDepartment(), mapOfEmployeeIdWithEmployeeEntity);
			mapOfEmployeeIdWithDepartment.remove(id);
			responseObjectVo.setResponseMessage(ResponseCodeAndMessage.EMPLOYEE_DELETED_SUCCESSFULLY+employee.getEmployeeId());
			return responseObjectVo;
			
		} 

	@Override
	public ResponseObject getTotalAllocationByEmployeeId(Long id) {
		ResponseObject responseObjectVo=new ResponseObject();
		//checking existing employee count
		if(mapOfEmployeeIdWithDepartment.size()>0) {
			//checking exiting employee ID
			if(mapOfEmployeeIdWithDepartment.get(id)==null) {
				responseObjectVo.setResponseCode(ResponseCodeAndMessage.ERROR_CODE);
				responseObjectVo.setResponseMessage(ResponseCodeAndMessage.NO_EMPLOYEE_FOUND_WITH+id);
			} else {
				responseObjectVo.setResponseObject(mapOfDepartmentNameWithEmployeeEntity.get(mapOfEmployeeIdWithDepartment.get(id)).get(id).getTotalAllocation());
				responseObjectVo.setResponseMessage(ResponseCodeAndMessage.TOTAL_ALLOCATION_FOR_EMPLOYEE +id+" is : "+responseObjectVo.getResponseObject());
			}
		} else {
			responseObjectVo.setResponseCode(ResponseCodeAndMessage.ERROR_CODE);
			responseObjectVo.setResponseMessage(ResponseCodeAndMessage.NO_EMPLOYEE_FOUND);
		}
		return responseObjectVo;
	}

	@Override
	public ResponseObject getTotalAllocationByDepartment(String department) {
		ResponseObject responseObject=new ResponseObject();
		//checking existing department
		if(mapOfDepartmentNameWithAllocation.containsKey(department)) {
			responseObject.setResponseObject(mapOfDepartmentNameWithAllocation.get(department));
			responseObject.setResponseMessage(ResponseCodeAndMessage.TOTAL_ALLOCATION_FOR_DEPARTMENT+mapOfDepartmentNameWithAllocation.get(department));
		} else {
			responseObject.setResponseCode(ResponseCodeAndMessage.ERROR_CODE);
			responseObject.setResponseMessage(ResponseCodeAndMessage.NO_DEPARTMENT_FOUND+department);
		}
		return responseObject;
	}

	@Override
	public ResponseObject getTotalAllocation() {
		ResponseObject responseObject=new ResponseObject();
		Long totalAllocation = 0l;
		//getting total allocation
		for (Entry<String, Long> iterable_element : mapOfDepartmentNameWithAllocation.entrySet()) {
			totalAllocation = totalAllocation + iterable_element.getValue();
		}
		responseObject.setResponseObject(totalAllocation);
		responseObject.setResponseMessage(ResponseCodeAndMessage.TOTAL_ALLOCATION+totalAllocation);
		return responseObject;
	}

	@Override
	public ResponseObject getTotalEmployeeCountByDepartment(String department) {
		ResponseObject responseObjectVo=new ResponseObject();
		//checking existing department
		if(mapOfDepartmentNameWithAllocation.containsKey(department)) {
			responseObjectVo.setResponseObject(mapOfDepartmentNameWithEmployeeEntity.get(department).size());
			responseObjectVo.setResponseMessage(ResponseCodeAndMessage.TOTAL_EMPLOYEE_FOR_DEPARTMENT+mapOfDepartmentNameWithEmployeeEntity.get(department).size());
		} else {
			responseObjectVo.setResponseCode(ResponseCodeAndMessage.ERROR_CODE);
			responseObjectVo.setResponseMessage(ResponseCodeAndMessage.NO_DEPARTMENT_FOUND+department);
		}
		return responseObjectVo;
	}

	@Override
	public ResponseObject getTotalEmployeeCount() {
		ResponseObject responseObject=new ResponseObject();
		int size = mapOfEmployeeIdWithDepartment.size();
		responseObject.setResponseObject(size);
		responseObject.setResponseMessage(ResponseCodeAndMessage.TOTAL_EMPLOYEE+size);
		return responseObject;
	}

	@Override
	public ResponseObject getManagerWithOutEmployeeByDepartment(String department) {
		ResponseObject responseObjectVo=new ResponseObject();
		Map<Long,Employee> managerIdWithEmployeeMap = new HashMap<>();

		//checking existing department
		if(mapOfDepartmentNameWithAllocation.containsKey(department)) {
			for (Entry<Long, Employee> iterable_element : mapOfDepartmentNameWithEmployeeEntity.get(department).entrySet()) {
				if(iterable_element.getValue().getDesignation().equalsIgnoreCase(ResponseCodeAndMessage.MANAGER)) {
					managerIdWithEmployeeMap.put(iterable_element.getKey(), iterable_element.getValue());
				}
			}
			if(managerIdWithEmployeeMap.size()==0)
			{
				responseObjectVo.setResponseMessage(ResponseCodeAndMessage.MANAGER_WITHOUT_EMPLOYEE+managerIdWithEmployeeMap.size());
				return responseObjectVo;
			}
			for (Entry<Long, Employee> iterable_element : mapOfDepartmentNameWithEmployeeEntity.get(department).entrySet()) {
				Long reportingManagerId = iterable_element.getValue().getReportingManagerId();
				if(managerIdWithEmployeeMap.containsKey(reportingManagerId)) {
					managerIdWithEmployeeMap.remove(reportingManagerId);
				}
			}
			if(managerIdWithEmployeeMap.size()==0)
			{
				responseObjectVo.setResponseMessage(ResponseCodeAndMessage.MANAGER_WITHOUT_EMPLOYEE+managerIdWithEmployeeMap.size());
				return responseObjectVo;
			} else {
				responseObjectVo.setResponseMessage(ResponseCodeAndMessage.MANAGER_WITHOUT_EMPLOYEE+managerIdWithEmployeeMap.size());
				responseObjectVo.setResponseObject(managerIdWithEmployeeMap.values());
				return responseObjectVo;
			}

		} else {
			responseObjectVo.setResponseCode(ResponseCodeAndMessage.ERROR_CODE);
			responseObjectVo.setResponseMessage(ResponseCodeAndMessage.NO_DEPARTMENT_FOUND+department);
		}
		return responseObjectVo;
	}

	@Override
	public ResponseObject deleteAllEmployee() {
		ResponseObject responseObject=new ResponseObject();
		responseObject.setResponseMessage(ResponseCodeAndMessage.ALL_EMPLOYEE_DELETE);
		
		//deleting all data 
		mapOfDepartmentNameWithEmployeeEntity.clear();
		mapOfEmployeeIdWithDepartment.clear();
		mapOfDepartmentNameWithAllocation.clear();
		
		return responseObject;
	}

}
