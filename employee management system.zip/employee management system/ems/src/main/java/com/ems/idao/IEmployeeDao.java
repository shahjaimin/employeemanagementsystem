package com.ems.idao;

import com.ems.model.Employee;
import com.ems.model.ResponseObject;

public interface IEmployeeDao {

	public ResponseObject addEmployee(Employee employee);
	
	public ResponseObject getTotalEmployee();

	public ResponseObject getEmployeeById(Long id);

	public ResponseObject deleteEmployeeById(Long id);

	public ResponseObject getTotalAllocationByEmployeeId(Long id);

	public ResponseObject getTotalAllocationByDepartment(String department);

	public ResponseObject getTotalAllocation();

	public ResponseObject getTotalEmployeeCountByDepartment(String department);

	public ResponseObject getTotalEmployeeCount();

	public ResponseObject getManagerWithOutEmployeeByDepartment(String department);

	public ResponseObject deleteAllEmployee();
}
