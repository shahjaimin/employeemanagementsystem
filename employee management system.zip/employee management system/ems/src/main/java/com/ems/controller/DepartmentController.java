package com.ems.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ems.iservice.IEmployeeService;
import com.ems.model.ResponseObject;

@RestController
@RequestMapping("/ems/department/")
public class DepartmentController {
	
	@Autowired
	IEmployeeService iEmployeeService;
	
	@GetMapping("{department}")
	ResponseEntity<ResponseObject> getTotalEmployeeCountByDepartment(@PathVariable("department") String department) {
		ResponseObject responseObjectVo=iEmployeeService.getTotalEmployeeCountByDepartment(department);
		if(responseObjectVo.isError())
		{
			return new ResponseEntity<ResponseObject>(responseObjectVo, HttpStatus.BAD_REQUEST);
		} 
		return new ResponseEntity<ResponseObject>(responseObjectVo, HttpStatus.OK);
	}
}
