package com.ems.model;

public class Employee {
	private String name;
	private String designation;
	private Long reportingManagerId;
	private String department;
	private Long employeeId;
	private Long salary;
	private Long totalAllocation;
	
	public Long getTotalAllocation() {
		return totalAllocation;
	}
	public void setTotalAllocation(Long totalAllocation) {
		this.totalAllocation = totalAllocation;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public Long getReportingManagerId() {
		return reportingManagerId;
	}
	public void setReportingManagerId(Long reportingManagerId) {
		this.reportingManagerId = reportingManagerId;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public Long getSalary() {
		return salary;
	}
	public void setSalary(Long salary) {
		this.salary = salary;
	}
	public Long getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Long employeeId) {
		this.employeeId = employeeId;
	}
	@Override
	public String toString() {
		return "Employee [name=" + name + ", designation=" + designation + ", reportingManagerId="
				+ reportingManagerId + ", department=" + department + ", employeeId=" + employeeId + ", salary="
				+ salary + ", totalAllocation=" + totalAllocation + "]";
	}
}
