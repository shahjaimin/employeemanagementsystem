package com.ems.model;

import java.util.Arrays;
import java.util.List;

public class ResponseCodeAndMessage {
	
	public static final long ERROR_CODE = -1l;
	
	public static final Long MANAGER_ALLOCATION = 600l;
	
	public static final Long DEVELOPER_ALLOCATION = 2000l;
	
	public static final Long TESTER_ALLOCATION = 1000l;

	public static final String MANAGER = "MANAGER";
	
	public static final String DEVELOPER = "DEVELOPER";
	
	public static final String TESTER = "TESTER";
	
	public static final String NO_DEPARTMENT_FOUND = "No, Department is found : ";

	public static final String MANAGER_WITHOUT_EMPLOYEE = "Total Manager WithOut Employee is : ";
	
	public static final String NO_EMPLOYEE_FOUND = "No, Employee are found!!!";
	
	public static final String NO_EMPLOYEE_FOUND_WITH = "No, Employee are found!!! with ID : ";
	
	public static final String TOTAL_ALLOCATION = "Total allocation is : ";
	
	public static final String TOTAL_EMPLOYEE = "Total employee is : ";
	
	public static final String EMPLOYEE_DELETED_SUCCESSFULLY = "Employee deleted successfully with employee ID : ";
	
	public static final String EMPLOYEE_CREATED_SUCCESSFULLY = "Employee created successfully with employee ID : ";
	
	public static final String TOTAL_ALLOCATION_FOR_DEPARTMENT = "Total allocation for department is : ";
	
	public static final String TOTAL_ALLOCATION_FOR_EMPLOYEE = "Total allocation for Employee Id ";
	
	public static final String TOTAL_EMPLOYEE_FOR_DEPARTMENT = "Total employee for department is : ";
	
	public static final String MANAGER_NOTFOUND_WITH_ID = "Manager not found with employee ID : ";
	
	public static final String REPORTING_MANAGER_NOTFOUND = "Reporting manager can't be transferred";
	
	public static final String WELCOME_MESSAGE = "Welcome TO Employee Management System";
	
	public static final List<String> DESIGNATION_LIST = Arrays.asList("MANAGER","DEVELOPER","TESTER");

	public static final String ALL_EMPLOYEE_DELETE = "All employee deleted successfully";
	
}
