package com.ems.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ems.iservice.IEmployeeService;
import com.ems.model.Employee;
import com.ems.model.ResponseObject;


@RestController
@RequestMapping("/ems/employee/")
public class EmployeeController {
	
	@Autowired
	IEmployeeService iEmployeeService;
	
	@RequestMapping("add")
	ResponseEntity<ResponseObject> addEmployee(@RequestBody Employee employee) {
		ResponseObject responseObjectVo=new ResponseObject();
			responseObjectVo=iEmployeeService.addEmployee(employee);
			if(responseObjectVo.isError())
			{
				return new ResponseEntity<ResponseObject>(responseObjectVo, HttpStatus.BAD_REQUEST);
			} 
			return new ResponseEntity<ResponseObject>(responseObjectVo, HttpStatus.OK);
	}
	
	@GetMapping("byid/{id}")
	ResponseEntity<ResponseObject> getEmployeeById(@PathVariable("id") Long id) {
		ResponseObject responseObjectVo=iEmployeeService.getEmployeeById(id);
		if(responseObjectVo.isError())
		{
			return new ResponseEntity<ResponseObject>(responseObjectVo, HttpStatus.BAD_REQUEST);
		} 
		return new ResponseEntity<ResponseObject>(responseObjectVo, HttpStatus.OK);
	}
	
	@DeleteMapping("byid/{id}")
	ResponseEntity<ResponseObject> deleteEmployeeById(@PathVariable("id") Long id) {
		ResponseObject responseObjectVo=iEmployeeService.deleteEmployeeById(id);
		if(responseObjectVo.isError())
		{
			return new ResponseEntity<ResponseObject>(responseObjectVo, HttpStatus.BAD_REQUEST);
		} 
		return new ResponseEntity<ResponseObject>(responseObjectVo, HttpStatus.OK);
	}
	
	@GetMapping("all")
	ResponseEntity<ResponseObject> getTotalEmployee() {
		ResponseObject responseObjectVo=iEmployeeService.getTotalEmployee();
		if(responseObjectVo.isError())
		{
			return new ResponseEntity<ResponseObject>(responseObjectVo, HttpStatus.BAD_REQUEST);
		} 
		return new ResponseEntity<ResponseObject>(responseObjectVo, HttpStatus.OK);
	}
	
	@DeleteMapping("all")
	ResponseEntity<ResponseObject> deleteAllEmployee() {
		ResponseObject responseObjectVo=iEmployeeService.deleteAllEmployee();
		if(responseObjectVo.isError())
		{
			return new ResponseEntity<ResponseObject>(responseObjectVo, HttpStatus.BAD_REQUEST);
		} 
		return new ResponseEntity<ResponseObject>(responseObjectVo, HttpStatus.OK);
	}
	
	@GetMapping("count")
	ResponseEntity<ResponseObject> getTotalEmployeeCount() {
		ResponseObject responseObjectVo=iEmployeeService.getTotalEmployeeCount();
		if(responseObjectVo.isError())
		{
			return new ResponseEntity<ResponseObject>(responseObjectVo, HttpStatus.BAD_REQUEST);
		} 
		return new ResponseEntity<ResponseObject>(responseObjectVo, HttpStatus.OK);
	}
	
	@GetMapping("withoutemployee/{department}")
	ResponseEntity<ResponseObject> getManagerWithOutEmployeeByDepartment(@PathVariable("department") String department) {
		ResponseObject responseObjectVo=iEmployeeService.getManagerWithOutEmployeeByDepartment(department);
		if(responseObjectVo.isError())
		{
			return new ResponseEntity<ResponseObject>(responseObjectVo, HttpStatus.BAD_REQUEST);
		} 
		return new ResponseEntity<ResponseObject>(responseObjectVo, HttpStatus.OK);
	}
}
