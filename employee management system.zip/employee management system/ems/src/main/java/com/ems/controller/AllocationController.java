package com.ems.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ems.iservice.IEmployeeService;
import com.ems.model.ResponseObject;

@RestController
@RequestMapping("/ems/allocation/")
public class AllocationController {

	@Autowired
	IEmployeeService iEmployeeService;
	
	@GetMapping("all")
	ResponseEntity<ResponseObject> getTotalAllocation() {
		ResponseObject responseObjectVo=iEmployeeService.getTotalAllocation();
		if(responseObjectVo.isError())
		{
			return new ResponseEntity<ResponseObject>(responseObjectVo, HttpStatus.BAD_REQUEST);
		} 
		return new ResponseEntity<ResponseObject>(responseObjectVo, HttpStatus.OK);
	}
	
	@GetMapping("bydepartment/{department}")
	ResponseEntity<ResponseObject> getTotalAllocationByDepartment(@PathVariable("department") String department) {
		ResponseObject responseObjectVo=iEmployeeService.getTotalAllocationByDepartment(department);
		if(responseObjectVo.isError())
		{
			return new ResponseEntity<ResponseObject>(responseObjectVo, HttpStatus.BAD_REQUEST);
		} 
		return new ResponseEntity<ResponseObject>(responseObjectVo, HttpStatus.OK);
	}
	
	@GetMapping("byemployee/{id}")
	ResponseEntity<ResponseObject> getTotalAllocationByEmployeeId(@PathVariable("id") Long id) {
		ResponseObject responseObjectVo=iEmployeeService.getTotalAllocationByEmployeeId(id);
		if(responseObjectVo.isError())
		{
			return new ResponseEntity<ResponseObject>(responseObjectVo, HttpStatus.BAD_REQUEST);
		} 
		return new ResponseEntity<ResponseObject>(responseObjectVo, HttpStatus.OK);
	}
}
