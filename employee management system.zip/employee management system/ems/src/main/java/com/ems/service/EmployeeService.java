package com.ems.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ems.idao.IEmployeeDao;
import com.ems.iservice.IEmployeeService;
import com.ems.model.Employee;
import com.ems.model.ResponseCodeAndMessage;
import com.ems.model.ResponseObject;

@Repository
public class EmployeeService implements IEmployeeService{
	
	@Autowired
	IEmployeeDao iEmployeeDao;
	
	@Override
	public ResponseObject addEmployee(Employee employee) {
		ResponseObject responseObjectVo=new ResponseObject();
		
		// validating all the field in service
		// else we can also take json validation on entity such as @NotNull @Min etc
		responseObjectVo = validateEmployee(employee);
		return responseObjectVo;
	}

	@Override
	public ResponseObject getTotalEmployee() {
		ResponseObject responseObjectVo=new ResponseObject();
		responseObjectVo = iEmployeeDao.getTotalEmployee();
		return responseObjectVo;
	}
	
	private ResponseObject validateEmployee(Employee employee) {
		ResponseObject responseObjectVo=new ResponseObject();
		responseObjectVo = validateString(employee.getDesignation());
		if(responseObjectVo.isError())
		{
			responseObjectVo.setResponseMessage("please provide valid : designation");
			return responseObjectVo;
		}
		
		if(!ResponseCodeAndMessage.DESIGNATION_LIST.contains(employee.getDesignation().trim().toUpperCase()))
		{
			responseObjectVo.setResponseMessage("please provide valid : designation For exa. : MANAGER,DEVELOPERS,TESTER");
			return responseObjectVo; 
		}
		
		if(employee.getReportingManagerId()==0 && !employee.getDesignation().trim().equalsIgnoreCase("Manager"))
		{
			responseObjectVo.setResponseMessage("please provide valid reporting manager ID");
			return responseObjectVo;
		}
		responseObjectVo = validateLong(employee.getReportingManagerId());
		if(responseObjectVo.isError())
		{
			responseObjectVo.setResponseMessage("please provide valid : reporting manager ID");
			return responseObjectVo;
		}
			
		responseObjectVo = validateString(employee.getDepartment());
		if(responseObjectVo.isError())
		{
			responseObjectVo.setResponseMessage("please provide valid : department");
			return responseObjectVo;
		}
		
		responseObjectVo = validateString(employee.getName());
		if(responseObjectVo.isError())
		{
			responseObjectVo.setResponseMessage("please provide valid : name");
			return responseObjectVo;
		}
		responseObjectVo = iEmployeeDao.addEmployee(employee);
		return responseObjectVo;
	}
	
	
	private ResponseObject validateLong(Long id) {
		ResponseObject responseObjectVo=new ResponseObject();
		if(id!=null)
		{
			// Only allow 0 and greater than 0
			if(id >= 0)
			{
				return responseObjectVo;
			}
			else {
				responseObjectVo.setResponseCode(-1l);
				return responseObjectVo;
			}
		} else {
			responseObjectVo.setResponseCode(-1l);
			return responseObjectVo;
		}
	}
	
	private ResponseObject validateString(String stringValue) {
		ResponseObject responseObjectVo=new ResponseObject();
		if(stringValue!=null)
		{
			// Only allow characters and spaces
			if(stringValue.matches("^[a-zA-Z ]*$"))
			{
				return responseObjectVo;
			}
			else {
				responseObjectVo.setResponseCode(-1l);
				return responseObjectVo;
			}
		} else {
			responseObjectVo.setResponseCode(-1l);
			return responseObjectVo;
		}
	}

	@Override
	public ResponseObject getEmployeeById(Long id) {
		ResponseObject responseObjectVo=new ResponseObject();
		responseObjectVo = iEmployeeDao.getEmployeeById(id);
		return responseObjectVo;
	}

	@Override
	public ResponseObject deleteEmployeeById(Long id) {
		ResponseObject responseObjectVo=new ResponseObject();
		responseObjectVo = iEmployeeDao.deleteEmployeeById(id);
		return responseObjectVo;
	}

	@Override
	public ResponseObject getTotalAllocationByEmployeeId(Long id) {
		ResponseObject responseObjectVo=new ResponseObject();
		responseObjectVo = iEmployeeDao.getTotalAllocationByEmployeeId(id);
		return responseObjectVo;
	}

	@Override
	public ResponseObject getTotalAllocationByDepartment(String department) {
		ResponseObject responseObjectVo=new ResponseObject();
		responseObjectVo = iEmployeeDao.getTotalAllocationByDepartment(department);
		return responseObjectVo;
	}

	@Override
	public ResponseObject getTotalAllocation() {
		ResponseObject responseObjectVo=new ResponseObject();
		responseObjectVo = iEmployeeDao.getTotalAllocation();
		return responseObjectVo;
	}

	@Override
	public ResponseObject getTotalEmployeeCountByDepartment(String department) {
		ResponseObject responseObjectVo=new ResponseObject();
		responseObjectVo = iEmployeeDao.getTotalEmployeeCountByDepartment(department);
		return responseObjectVo;
	}

	@Override
	public ResponseObject getTotalEmployeeCount() {
		ResponseObject responseObjectVo=new ResponseObject();
		responseObjectVo = iEmployeeDao.getTotalEmployeeCount();
		return responseObjectVo;
	}

	@Override
	public ResponseObject getManagerWithOutEmployeeByDepartment(String department) {
		ResponseObject responseObjectVo=new ResponseObject();
		responseObjectVo = iEmployeeDao.getManagerWithOutEmployeeByDepartment(department);
		return responseObjectVo;
	}

	@Override
	public ResponseObject deleteAllEmployee() {
		ResponseObject responseObjectVo=new ResponseObject();
		responseObjectVo = iEmployeeDao.deleteAllEmployee();
		return responseObjectVo;
	}

}
