package com.ems.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ems.model.ResponseCodeAndMessage;
import com.ems.model.ResponseObject;

@RestController
@RequestMapping("/ems/")
public class HomeController {
	@RequestMapping("home")
	ResponseObject home() {
		ResponseObject responseObjectVo=new ResponseObject();
		responseObjectVo.setResponseMessage(ResponseCodeAndMessage.WELCOME_MESSAGE);
		return responseObjectVo;
	}
}
