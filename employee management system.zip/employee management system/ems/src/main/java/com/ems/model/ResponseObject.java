package com.ems.model;

public class ResponseObject {
	private String responseMessage;
	private long responseCode;
    private Object responseObject;
    private boolean error;
    
    public boolean isError() {
		if(this.getResponseCode()<0)
			return true;
		else
			return false;
	}
    
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public long getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(long responseCode) {
		this.responseCode = responseCode;
	}
	public Object getResponseObject() {
		return responseObject;
	}
	public void setResponseObject(Object responseObject) {
		this.responseObject = responseObject;
	}
	public void setError(boolean error) {
		this.error = error;
	}
	@Override
	public String toString() {
		return "ResponseObject [responseMessage=" + responseMessage + ", responseCode=" + responseCode
				+ ", responseObject=" + responseObject + ", error=" + error + "]";
	}
	
}
