package com.ems;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.ems.idao.IEmployeeDao;
import com.ems.model.Employee;
import com.ems.model.ResponseCodeAndMessage;
import com.ems.model.ResponseObject;

@SpringBootTest
class EmsApplicationTests {

	public static final Long MANAGER_ALLOCATION = ResponseCodeAndMessage.MANAGER_ALLOCATION;
	
	public static final Long DEVELOPER_ALLOCATION = ResponseCodeAndMessage.DEVELOPER_ALLOCATION;
	
	public static final Long TESTER_ALLOCATION = ResponseCodeAndMessage.TESTER_ALLOCATION;

	public static final String MANAGER = ResponseCodeAndMessage.MANAGER;
	
	public static final String DEVELOPER = ResponseCodeAndMessage.DEVELOPER;
	
	public static final String TESTER = ResponseCodeAndMessage.TESTER;
	
	@Autowired
	IEmployeeDao iEmployeeDao;
	
	@Test
	void aa_contextLoads() {
	}
	
	private void addEmployee() {
		ResponseObject responseObject=new ResponseObject();
		
		// we are creating 4 cases. M = manager, D=developer, T=tester, Digit stands for employee ID
		
		// IT department
		// M1->M2->M3
		// M4->M5->(T6,D7)
		// M8->(T9,D10)
		// M11->null
		
		// ECE department
		// M12->M13->(T14,D15)
		
		//creating case 1 for It department
		Employee employee = new Employee();
		employee.setDepartment("IT");
		employee.setName("one");
		employee.setDesignation(MANAGER);
		employee.setReportingManagerId(0l);
		responseObject = iEmployeeDao.addEmployee(employee);
		assertEquals(0l, responseObject.getResponseCode());
		
		employee.setDepartment("IT");
		employee.setName("two");
		employee.setDesignation(MANAGER);
		employee.setReportingManagerId(1l);
		responseObject = iEmployeeDao.addEmployee(employee);
		assertEquals(0l, responseObject.getResponseCode());
		
		employee.setDepartment("IT");
		employee.setName("three");
		employee.setDesignation(MANAGER);
		employee.setReportingManagerId(2l);
		responseObject = iEmployeeDao.addEmployee(employee);
		assertEquals(0l, responseObject.getResponseCode());
		
		//creating case 2 for It department
		employee.setDepartment("IT");
		employee.setName("four");
		employee.setDesignation(MANAGER);
		employee.setReportingManagerId(0l);
		responseObject = iEmployeeDao.addEmployee(employee);
		assertEquals(0l, responseObject.getResponseCode());
		
		employee.setDepartment("IT");
		employee.setName("five");
		employee.setDesignation(MANAGER);
		employee.setReportingManagerId(4l);
		responseObject = iEmployeeDao.addEmployee(employee);
		assertEquals(0l, responseObject.getResponseCode());
		
		employee.setDepartment("IT");
		employee.setName("six");
		employee.setDesignation(DEVELOPER);
		employee.setReportingManagerId(5l);
		responseObject = iEmployeeDao.addEmployee(employee);
		assertEquals(0l, responseObject.getResponseCode());
		
		employee.setDepartment("IT");
		employee.setName("seven");
		employee.setDesignation(TESTER);
		employee.setReportingManagerId(5l);
		responseObject = iEmployeeDao.addEmployee(employee);
		assertEquals(0l, responseObject.getResponseCode());
			
		//creating case 3 for It department
		employee.setDepartment("IT");
		employee.setName("eight");
		employee.setDesignation(MANAGER);
		employee.setReportingManagerId(0l);
		responseObject = iEmployeeDao.addEmployee(employee);
		assertEquals(0l, responseObject.getResponseCode());
		
		employee.setDepartment("IT");
		employee.setName("nine");
		employee.setDesignation(DEVELOPER);
		employee.setReportingManagerId(8l);
		responseObject = iEmployeeDao.addEmployee(employee);
		assertEquals(0l, responseObject.getResponseCode());
		
		employee.setDepartment("IT");
		employee.setName("ten");
		employee.setDesignation(TESTER);
		employee.setReportingManagerId(8l);
		responseObject = iEmployeeDao.addEmployee(employee);
		assertEquals(0l, responseObject.getResponseCode());
		
		//creating case 4 for It department
		employee.setDepartment("IT");
		employee.setName("eleven");
		employee.setDesignation(MANAGER);
		employee.setReportingManagerId(0l);
		responseObject = iEmployeeDao.addEmployee(employee);
		assertEquals(0l, responseObject.getResponseCode());
								
		//It department contains 7 managers + 2 developers + 2 testers, So total allocation = 10,200
		
		//creating case 4 for ECE department
		employee.setDepartment("ECE");
		employee.setName("twelve");
		employee.setDesignation(MANAGER);
		employee.setReportingManagerId(0l);
		responseObject = iEmployeeDao.addEmployee(employee);
		assertEquals(0l, responseObject.getResponseCode());
		
		employee.setDepartment("ECE");
		employee.setName("thirteen");
		employee.setDesignation(MANAGER);
		employee.setReportingManagerId(12l);
		responseObject = iEmployeeDao.addEmployee(employee);
		assertEquals(0l, responseObject.getResponseCode());
		
		employee.setDepartment("ECE");
		employee.setName("fourteen");
		employee.setDesignation(DEVELOPER);
		employee.setReportingManagerId(13l);
		responseObject = iEmployeeDao.addEmployee(employee);
		assertEquals(0l, responseObject.getResponseCode());
		
		employee.setDepartment("ECE");
		employee.setName("fifteen");
		employee.setDesignation(TESTER);
		employee.setReportingManagerId(13l);
		responseObject = iEmployeeDao.addEmployee(employee);
		assertEquals(0l, responseObject.getResponseCode());
		
	}

	@Test
	public void getTotalAllocationWithZeroTest() {
		ResponseObject responseObject=new ResponseObject();
		//checking total allocation
		responseObject = iEmployeeDao.getTotalAllocation();
		assertEquals(0l, responseObject.getResponseObject());
	}
	
	@Test
	public void getTotalAllocationSuccessfullyTest() {
		ResponseObject responseObject=new ResponseObject();
		addEmployee();
		//checking total allocation
		responseObject = iEmployeeDao.getTotalAllocation();
		assertEquals((MANAGER_ALLOCATION*9)+(DEVELOPER_ALLOCATION*3)+(TESTER_ALLOCATION*3), responseObject.getResponseObject());
		responseObject = iEmployeeDao.deleteAllEmployee();
		assertEquals(0, responseObject.getResponseCode());
	}
	
	@Test
	public void getTotalAllocationByEmployeeIdFailedTest() {
		ResponseObject responseObject=new ResponseObject();
		//checking total allocation of employee id 51
		responseObject = iEmployeeDao.getTotalAllocationByEmployeeId(51l);
		assertEquals(-1, responseObject.getResponseCode());
	}
	
	@Test
	public void getTotalAllocationByEmployeeIdSuccessfullyTest() {
		ResponseObject responseObject=new ResponseObject();
		addEmployee();
		//checking total allocation of manager with employee id 1
		responseObject = iEmployeeDao.getTotalAllocationByEmployeeId(1l);
		assertEquals(MANAGER_ALLOCATION*3, responseObject.getResponseObject());
		
		//checking total allocation of manager with employee id 4
		responseObject = iEmployeeDao.getTotalAllocationByEmployeeId(4l);
		assertEquals((MANAGER_ALLOCATION*2)+(DEVELOPER_ALLOCATION*1)+(TESTER_ALLOCATION*1), responseObject.getResponseObject());
				
		//checking total allocation of manager with employee id 8
		responseObject = iEmployeeDao.getTotalAllocationByEmployeeId(8l);
		assertEquals((MANAGER_ALLOCATION*1)+(DEVELOPER_ALLOCATION*1)+(TESTER_ALLOCATION*1), responseObject.getResponseObject());
		
		//checking total allocation of manager with employee id 11
		responseObject = iEmployeeDao.getTotalAllocationByEmployeeId(11l);
		assertEquals((MANAGER_ALLOCATION*1), responseObject.getResponseObject());
					
		//checking total allocation of manager with employee id 12
		responseObject = iEmployeeDao.getTotalAllocationByEmployeeId(12l);
		assertEquals((MANAGER_ALLOCATION*2)+(DEVELOPER_ALLOCATION*1)+(TESTER_ALLOCATION*1), responseObject.getResponseObject());
		responseObject = iEmployeeDao.deleteAllEmployee();
		assertEquals(0l, responseObject.getResponseCode());
	}
	
	@Test
	public void getTotalAllocationByDepartmentFailedTest() {
		ResponseObject responseObject=new ResponseObject();
		//checking total allocation for CHEM department
		responseObject = iEmployeeDao.getTotalAllocationByDepartment("CHEM");
		assertEquals(-1, responseObject.getResponseCode());
	}
	
	@Test
	public void getTotalAllocationByDepartmentSuccessfullyTest() {
		ResponseObject responseObject=new ResponseObject();
		addEmployee();
		//checking total allocation for IT department = 10200
		responseObject = iEmployeeDao.getTotalAllocationByDepartment("IT");
		assertEquals(10200l, responseObject.getResponseObject());
							
		//checking total allocation for ECE department = 4200
		responseObject = iEmployeeDao.getTotalAllocationByDepartment("ECE");
		assertEquals(4200l, responseObject.getResponseObject());
		
		responseObject = iEmployeeDao.deleteAllEmployee();
		assertEquals(0l, responseObject.getResponseCode());
	}
	
	@Test
	public void getTotalEmployeeCountSuccessfullyTest() {
		ResponseObject responseObject=new ResponseObject();
		addEmployee();
		//checking total count of employee
		responseObject = iEmployeeDao.getTotalEmployeeCount();
		assertEquals(15, responseObject.getResponseObject());
		responseObject = iEmployeeDao.deleteAllEmployee();
		assertEquals(0l, responseObject.getResponseCode());
	}
	
	@Test
	public void addTesterAndDeveloperEmployeeFailed() {
		ResponseObject responseObject=new ResponseObject();
		//add tested and developer without having manager in department will be failed
		responseObject = iEmployeeDao.getTotalEmployeeCount();
		assertEquals(0, responseObject.getResponseObject());
		
		Employee employee = new Employee();
		employee.setDepartment("IT");
		employee.setName("one");
		employee.setDesignation(DEVELOPER);
		employee.setReportingManagerId(1l);
		responseObject = iEmployeeDao.addEmployee(employee);
		assertEquals(-1, responseObject.getResponseCode());
		assertEquals(ResponseCodeAndMessage.MANAGER_NOTFOUND_WITH_ID+1, responseObject.getResponseMessage());
		
		employee.setDepartment("IT");
		employee.setName("two");
		employee.setDesignation(TESTER);
		employee.setReportingManagerId(2l);
		responseObject = iEmployeeDao.addEmployee(employee);
		assertEquals(-1, responseObject.getResponseCode());
		assertEquals(ResponseCodeAndMessage.MANAGER_NOTFOUND_WITH_ID+2, responseObject.getResponseMessage());
		
	}
	
	@Test
	public void addManagerFailed() {
		ResponseObject responseObject=new ResponseObject();
		//add tested and developer without having manager in department will be failed
		responseObject = iEmployeeDao.getTotalEmployeeCount();
		assertEquals(0, responseObject.getResponseObject());
		
		Employee employee = new Employee();
		employee.setDepartment("IT");
		employee.setName("one");
		employee.setDesignation(MANAGER);
		employee.setReportingManagerId(1l);
		responseObject = iEmployeeDao.addEmployee(employee);
		assertEquals(-1, responseObject.getResponseCode());
		assertEquals(ResponseCodeAndMessage.MANAGER_NOTFOUND_WITH_ID+1, responseObject.getResponseMessage());
	}
	
	@Test
	public void getTotalEmployeeFailedTest() {
		ResponseObject responseObject=new ResponseObject();
		//checking total count of employee
		responseObject = iEmployeeDao.getTotalEmployeeCount();
		assertEquals(0, responseObject.getResponseObject());
		responseObject = iEmployeeDao.getTotalEmployee();
		assertEquals(-1, responseObject.getResponseCode());
		assertEquals(ResponseCodeAndMessage.NO_EMPLOYEE_FOUND, responseObject.getResponseMessage());
	}
	
	@Test
	public void getEmployeeByIdFailedTest() {
		ResponseObject responseObject=new ResponseObject();
		//checking total count of employee
		responseObject = iEmployeeDao.getTotalEmployeeCount();
		assertEquals(0, responseObject.getResponseObject());
		responseObject = iEmployeeDao.getEmployeeById(1l);
		assertEquals(-1, responseObject.getResponseCode());
		assertEquals(ResponseCodeAndMessage.NO_EMPLOYEE_FOUND, responseObject.getResponseMessage());
	}
	
	@Test
	public void getTotalEmployeeCountByDepartmentFailedTest() {
		ResponseObject responseObject=new ResponseObject();
		//checking total count of employee
		responseObject = iEmployeeDao.getTotalEmployeeCount();
		assertEquals(0, responseObject.getResponseObject());
		responseObject = iEmployeeDao.getTotalEmployeeCountByDepartment("CHEM");
		assertEquals(-1, responseObject.getResponseCode());
		assertEquals(ResponseCodeAndMessage.NO_DEPARTMENT_FOUND+"CHEM", responseObject.getResponseMessage());
	}
	
	@Test
	public void getTotalEmployeeCountByDepartmentSuccessfullyTest() {
		ResponseObject responseObject=new ResponseObject();
		addEmployee();
		//checking total count of employee
		responseObject = iEmployeeDao.getTotalEmployeeCount();
		assertEquals(15, responseObject.getResponseObject());
		
		responseObject = iEmployeeDao.getTotalEmployeeCountByDepartment("ECE");
		assertEquals(4, responseObject.getResponseObject());
		
		responseObject = iEmployeeDao.getTotalEmployeeCountByDepartment("IT");
		assertEquals(11, responseObject.getResponseObject());
		
		responseObject = iEmployeeDao.deleteAllEmployee();
		assertEquals(0l, responseObject.getResponseCode());
	}
	
	@Test
	public void getManagerWithOutEmployeeByDepartmentSuccessfullyTest() {
		ResponseObject responseObject=new ResponseObject();
		addEmployee();
		//checking total count of employee
		responseObject = iEmployeeDao.getTotalEmployeeCount();
		assertEquals(15, responseObject.getResponseObject());
		
		responseObject = iEmployeeDao.getManagerWithOutEmployeeByDepartment("ECE");
		assertEquals(ResponseCodeAndMessage.MANAGER_WITHOUT_EMPLOYEE+0, responseObject.getResponseMessage());
		
		responseObject = iEmployeeDao.getManagerWithOutEmployeeByDepartment("IT");
		assertEquals(ResponseCodeAndMessage.MANAGER_WITHOUT_EMPLOYEE+2, responseObject.getResponseMessage());
		
		responseObject = iEmployeeDao.deleteAllEmployee();
		assertEquals(0l, responseObject.getResponseCode());
	}
	
	@Test
	public void getManagerWithOutEmployeeByDepartmentFailedTest() {
		ResponseObject responseObject=new ResponseObject();
		responseObject = iEmployeeDao.getManagerWithOutEmployeeByDepartment("ECE");
		assertEquals(ResponseCodeAndMessage.NO_DEPARTMENT_FOUND+"ECE", responseObject.getResponseMessage());
	}
	
	@Test
	public void deleteEmployeeByIdFailedDueToNoEmployeeFoundTest() {
		ResponseObject responseObject=new ResponseObject();
		addEmployee();
		//checking total count of employee
		responseObject = iEmployeeDao.getTotalEmployeeCount();
		assertEquals(15, responseObject.getResponseObject());
		
		responseObject = iEmployeeDao.deleteEmployeeById(21L);
		assertEquals(ResponseCodeAndMessage.NO_EMPLOYEE_FOUND_WITH+21, responseObject.getResponseMessage());
		
		responseObject = iEmployeeDao.deleteAllEmployee();
		assertEquals(0l, responseObject.getResponseCode());
	}
	
	@Test
	public void deleteEmployeeByIdFailedDueToParentManagerTest() {
		ResponseObject responseObject=new ResponseObject();
		addEmployee();
		//checking total count of employee
		responseObject = iEmployeeDao.getTotalEmployeeCount();
		assertEquals(15, responseObject.getResponseObject());
		
		responseObject = iEmployeeDao.deleteEmployeeById(1L);
		assertEquals(ResponseCodeAndMessage.REPORTING_MANAGER_NOTFOUND, responseObject.getResponseMessage());
		assertEquals(-1, responseObject.getResponseCode());
		responseObject = iEmployeeDao.deleteEmployeeById(4L);
		assertEquals(ResponseCodeAndMessage.REPORTING_MANAGER_NOTFOUND, responseObject.getResponseMessage());
		assertEquals(-1, responseObject.getResponseCode());
		responseObject = iEmployeeDao.deleteEmployeeById(8L);
		assertEquals(ResponseCodeAndMessage.REPORTING_MANAGER_NOTFOUND, responseObject.getResponseMessage());
		assertEquals(-1, responseObject.getResponseCode());
		responseObject = iEmployeeDao.deleteAllEmployee();
		assertEquals(0l, responseObject.getResponseCode());
	}
	
	@Test
	public void deleteEmployeeByIdManagerDeletedSuccessfullyTest() {
		ResponseObject responseObject=new ResponseObject();
		addEmployee();
		//checking total count of employee
		responseObject = iEmployeeDao.getTotalEmployeeCount();
		assertEquals(15, responseObject.getResponseObject());
		
		responseObject = iEmployeeDao.getEmployeeById(11L);
		assertEquals(0, responseObject.getResponseCode());
		Employee employee = (Employee) responseObject.getResponseObject();
		assertEquals(MANAGER, employee.getDesignation());
		
		responseObject = iEmployeeDao.deleteEmployeeById(11l);
		assertEquals(0, responseObject.getResponseCode());
		responseObject = iEmployeeDao.getEmployeeById(11l);
		assertEquals(-1, responseObject.getResponseCode());
		
		responseObject = iEmployeeDao.deleteAllEmployee();
		assertEquals(0l, responseObject.getResponseCode());
	}
	
	@Test
	public void deleteEmployeeByIdTesterAndDeveloperDeletedSuccessfullyTest() {
		ResponseObject responseObject=new ResponseObject();
		addEmployee();
		//checking total count of employee
		responseObject = iEmployeeDao.getTotalEmployeeCount();
		assertEquals(15, responseObject.getResponseObject());
		
		responseObject = iEmployeeDao.getEmployeeById(6L);
		assertEquals(0, responseObject.getResponseCode());
		Employee employeeTester = (Employee) responseObject.getResponseObject();
		assertEquals(DEVELOPER, employeeTester.getDesignation());
		
		responseObject = iEmployeeDao.getEmployeeById(7L);
		assertEquals(0, responseObject.getResponseCode());
		Employee employeeDeveloper = (Employee) responseObject.getResponseObject();
		assertEquals(TESTER, employeeDeveloper.getDesignation());
		
		responseObject = iEmployeeDao.deleteEmployeeById(6l);
		assertEquals(0, responseObject.getResponseCode());
		responseObject = iEmployeeDao.getEmployeeById(6l);
		assertEquals(-1, responseObject.getResponseCode());
		
		responseObject = iEmployeeDao.deleteEmployeeById(7l);
		assertEquals(0, responseObject.getResponseCode());
		responseObject = iEmployeeDao.getEmployeeById(7l);
		assertEquals(-1, responseObject.getResponseCode());
		
		responseObject = iEmployeeDao.deleteAllEmployee();
		assertEquals(0l, responseObject.getResponseCode());
	}
	
	@Test
	public void deleteEmployeeByIdMidLevelMangerDeletedSuccessfullyTest() {
		ResponseObject responseObject=new ResponseObject();
		addEmployee();
		// checking total count of employee
		// M1->M2->M3
		// M4->M5->(T6,D7)
		// we are going to delete M2,M5, So M1->M3, M4->(T6,D7)
		responseObject = iEmployeeDao.getTotalEmployeeCount();
		assertEquals(15, responseObject.getResponseObject());
		
		responseObject = iEmployeeDao.getEmployeeById(2L);
		assertEquals(0, responseObject.getResponseCode());
		Employee employeemanagerId2 = (Employee) responseObject.getResponseObject();
		assertEquals(MANAGER, employeemanagerId2.getDesignation());
		
		responseObject = iEmployeeDao.getEmployeeById(5L);
		assertEquals(0, responseObject.getResponseCode());
		Employee employeemanagerId5 = (Employee) responseObject.getResponseObject();
		assertEquals(MANAGER, employeemanagerId5.getDesignation());
		
		responseObject = iEmployeeDao.getEmployeeById(3L);
		assertEquals(0, responseObject.getResponseCode());
		Employee employeemanagerId3 = (Employee) responseObject.getResponseObject();
		assertEquals(MANAGER, employeemanagerId3.getDesignation());
		assertTrue(employeemanagerId3.getReportingManagerId()==2l);
		
		responseObject = iEmployeeDao.getEmployeeById(6L);
		assertEquals(0, responseObject.getResponseCode());
		Employee employeeDeveloperId6 = (Employee) responseObject.getResponseObject();
		assertEquals(DEVELOPER, employeeDeveloperId6.getDesignation());
		assertTrue(employeeDeveloperId6.getReportingManagerId()==5l);
		
		responseObject = iEmployeeDao.getEmployeeById(7L);
		assertEquals(0, responseObject.getResponseCode());
		Employee employeeTesterId7 = (Employee) responseObject.getResponseObject();
		assertEquals(TESTER, employeeTesterId7.getDesignation());
		assertTrue(employeeTesterId7.getReportingManagerId()==5l);
		
		
		responseObject = iEmployeeDao.getEmployeeById(1L);
		assertEquals(0, responseObject.getResponseCode());
		Employee employeemanagerId1 = (Employee) responseObject.getResponseObject();
		assertEquals(MANAGER, employeemanagerId1.getDesignation());
		assertTrue(employeemanagerId1.getTotalAllocation()==1800L);
		
		responseObject = iEmployeeDao.getEmployeeById(4L);
		assertEquals(0, responseObject.getResponseCode());
		Employee employeemanagerId4 = (Employee) responseObject.getResponseObject();
		assertEquals(MANAGER, employeemanagerId4.getDesignation());
		assertTrue(employeemanagerId4.getTotalAllocation()==4200L);
		
		// proceed for deletion
		
		responseObject = iEmployeeDao.deleteEmployeeById(2l);
		assertEquals(0, responseObject.getResponseCode());
		responseObject = iEmployeeDao.getEmployeeById(2l);
		assertEquals(-1, responseObject.getResponseCode());
		
		responseObject = iEmployeeDao.deleteEmployeeById(5l);
		assertEquals(0, responseObject.getResponseCode());
		responseObject = iEmployeeDao.getEmployeeById(5l);
		assertEquals(-1, responseObject.getResponseCode());
		
		
		// after deletion
		
		responseObject = iEmployeeDao.getEmployeeById(1L);
		assertEquals(0, responseObject.getResponseCode());
		employeemanagerId1 = (Employee) responseObject.getResponseObject();
		assertTrue(employeemanagerId1.getTotalAllocation()==1200L);
		
		responseObject = iEmployeeDao.getEmployeeById(4L);
		assertEquals(0, responseObject.getResponseCode());
		employeemanagerId4 = (Employee) responseObject.getResponseObject();
		assertTrue(employeemanagerId4.getTotalAllocation()==3600L);
		
		responseObject = iEmployeeDao.getEmployeeById(3L);
		assertEquals(0, responseObject.getResponseCode());
		employeemanagerId3 = (Employee) responseObject.getResponseObject();
		assertEquals(MANAGER, employeemanagerId3.getDesignation());
		assertTrue(employeemanagerId3.getReportingManagerId()==1l);
		
		responseObject = iEmployeeDao.getEmployeeById(6L);
		assertEquals(0, responseObject.getResponseCode());
		employeeDeveloperId6 = (Employee) responseObject.getResponseObject();
		assertEquals(DEVELOPER, employeeDeveloperId6.getDesignation());
		assertTrue(employeeDeveloperId6.getReportingManagerId()==4l);
		
		responseObject = iEmployeeDao.getEmployeeById(7L);
		assertEquals(0, responseObject.getResponseCode());
		employeeTesterId7 = (Employee) responseObject.getResponseObject();
		assertEquals(TESTER, employeeTesterId7.getDesignation());
		assertTrue(employeeTesterId7.getReportingManagerId()==4l);
		
		responseObject = iEmployeeDao.deleteAllEmployee();
		assertEquals(0l, responseObject.getResponseCode());
	}
	
	@Test
	public void getTotalEmployeeSuccessfullyTest() {
		ResponseObject responseObject=new ResponseObject();
		addEmployee();
		
		responseObject = iEmployeeDao.getTotalEmployee();
		Map<String,Map<Long,Employee>> mapOfDepartmentNameWithEmployeeEntity = (Map<String, Map<Long, Employee>>) responseObject.getResponseObject();
		
		assertTrue(mapOfDepartmentNameWithEmployeeEntity.containsKey("IT"));
		assertTrue(mapOfDepartmentNameWithEmployeeEntity.containsKey("ECE"));
		assertTrue(mapOfDepartmentNameWithEmployeeEntity.get("IT").size()==11);
		assertTrue(mapOfDepartmentNameWithEmployeeEntity.get("ECE").size()==4);
		
		responseObject = iEmployeeDao.deleteAllEmployee();
		assertEquals(0l, responseObject.getResponseCode());
	}
	
	


}
